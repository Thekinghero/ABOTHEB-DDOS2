# Sms-nodejs
Install nodejs(ติดตั้งnodejs) => apt install nodejs
_______________________________
Install npm(ติดตั้งnpm) => apt install npm
_______________________________
Install Module(ติดตั้งโมดูล) => npm i axios randomstring form-data qs https-proxy-agent prompt-sync
_______________________________
Run(การรัน) => node shadowsms.js (เบอร์) (จำนวน)
_______________________________
example(ตัวอย่าง) => node shadowsms.js 0987654321 10
_______________________________
